
import React from "react";
import CIODashboard from "./CIODashboard";

function App() {
  return <CIODashboard />;
}

export default App;
