
import React from "react";

export default function CIODashboard() {
  const banks = ["CFG", "PB", "WAL", "FFIN"];

  return (
    <div style={{ padding: '2rem' }}>
      <h1 style={{ fontSize: '2rem', fontWeight: 'bold' }}>Manthano Capital Internal Portal</h1>

      <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem', marginBottom: '2rem' }}>
        <input
          type="text"
          placeholder="Search transcripts, banks, keywords (e.g. 'CFG SLB Q1')"
          style={{ flex: 1, padding: '0.5rem', fontSize: '1rem' }}
        />
        <button style={{ padding: '0.5rem 1rem' }}>Search</button>
      </div>

      <div>
        <button style={{ marginRight: '1rem' }}>Overview</button>
        <button style={{ marginRight: '1rem' }}>Bank Profiles</button>
        <button style={{ marginRight: '1rem' }}>Recent Summaries</button>
        <button>Thematic Insights</button>
      </div>

      <hr style={{ margin: '1rem 0' }} />

      <section>
        <h2 style={{ fontSize: '1.25rem', fontWeight: '600' }}>Latest Strategic Highlights</h2>
        <ul style={{ marginTop: '0.5rem' }}>
          <li>CFG flagged as SLB candidate due to low CET1 and high branch ownership</li>
          <li>WAL raised deposit guidance for 2H25, notes improving churn trends</li>
          <li>PB, FFIN, and VLY all warned on CRE repricing challenges in TX market</li>
        </ul>
      </section>

      <hr style={{ margin: '2rem 0' }} />

      <section>
        <h2 style={{ fontSize: '1.25rem', fontWeight: '600' }}>Bank Profiles</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '1rem', marginTop: '1rem' }}>
          {banks.map((bank) => (
            <div key={bank} style={{ border: '1px solid #ccc', borderRadius: '0.5rem', padding: '1rem' }}>
              <h3 style={{ fontWeight: '600' }}>{bank}</h3>
              <p style={{ fontSize: '0.875rem', color: '#555' }}>Last updated: Q1 2025</p>
              <p style={{ fontSize: '0.875rem' }}>SLB flagged | CRE exposure 34% | CET1 9.3%</p>
            </div>
          ))}
        </div>
      </section>

      <hr style={{ margin: '2rem 0' }} />

      <section>
        <h2 style={{ fontSize: '1.25rem', fontWeight: '600' }}>Recent Summaries</h2>
        <div style={{ marginTop: '1rem' }}>
          {banks.slice(0, 3).map((bank) => (
            <div key={bank} style={{ border: '1px solid #ccc', borderRadius: '0.5rem', padding: '1rem', marginBottom: '1rem' }}>
              <h3 style={{ fontWeight: '600' }}>{bank} – 1Q25 Summary</h3>
              <p style={{ fontSize: '0.875rem' }}>
                Beat on NII, slight miss on fee income. Management raised NIM guide for 2Q. CRE criticized by 2 analysts, but tone remained constructive. No update on buyback plans.
              </p>
            </div>
          ))}
        </div>
      </section>

      <hr style={{ margin: '2rem 0' }} />

      <section>
        <h2 style={{ fontSize: '1.25rem', fontWeight: '600' }}>Thematic Search: SLB Trends</h2>
        <textarea
          readOnly
          rows={6}
          value={`CFG: "We are exploring monetizing our owned branches"
WAL: "Open to non-core asset sales, including property"
PB: "Too early to discuss sale-leaseback, but evaluating capital flexibility"
FFIN: "No plans for SLB given owned-to-branch ratio under 30%"`}
          style={{ width: '100%', marginTop: '1rem', padding: '0.5rem', fontSize: '0.875rem' }}
        />
      </section>
    </div>
  );
}
