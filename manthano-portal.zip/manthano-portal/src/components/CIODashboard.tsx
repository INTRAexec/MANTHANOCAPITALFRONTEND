import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

export default function CIODashboard() {
  return (
    <div className="p-8 space-y-6">
      <h1 className="text-3xl font-bold">Manthano Capital Internal Portal</h1>
      <div className="flex gap-4">
        <Input placeholder="Search transcripts, banks, keywords (e.g. 'CFG SLB Q1')" className="w-full" />
        <Button>Search</Button>
      </div>
      <Tabs defaultValue="dashboard">
        <TabsList>
          <TabsTrigger value="dashboard">Overview</TabsTrigger>
          <TabsTrigger value="banks">Bank Profiles</TabsTrigger>
          <TabsTrigger value="summaries">Recent Summaries</TabsTrigger>
          <TabsTrigger value="themes">Thematic Insights</TabsTrigger>
        </TabsList>
        <TabsContent value="dashboard">
          <Card>
            <CardContent className="p-6 space-y-4">
              <h2 className="text-xl font-semibold">Latest Strategic Highlights</h2>
              <ul className="list-disc list-inside text-sm space-y-2">
                <li>CFG flagged as SLB candidate due to low CET1 and high branch ownership</li>
                <li>WAL raised deposit guidance for 2H25, notes improving churn trends</li>
                <li>PB, FFIN, and VLY all warned on CRE repricing challenges in TX market</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="banks">
          <div className="grid grid-cols-3 gap-4">
            {["CFG", "PB", "WAL", "FFIN"].map((bank) => (
              <Card key={bank} className="hover:shadow-xl cursor-pointer">
                <CardContent className="p-4">
                  <h3 className="font-semibold text-lg">{bank}</h3>
                  <p className="text-sm text-muted-foreground">Last updated: Q1 2025</p>
                  <p className="mt-2 text-sm">SLB flagged | CRE exposure 34% | CET1 9.3%</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="summaries">
          <div className="space-y-4">
            {["CFG", "PB", "WAL"].map((bank) => (
              <Card key={bank}>
                <CardContent className="p-4">
                  <h3 className="font-semibold">{bank} – 1Q25 Summary</h3>
                  <p className="text-sm mt-2">
                    Beat on NII, slight miss on fee income. Management raised NIM guide for 2Q. CRE criticized by 2 analysts, but tone remained constructive. No update on buyback plans.
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="themes">
          <Card>
            <CardContent className="p-6 space-y-4">
              <h2 className="text-xl font-semibold">Thematic Search: SLB Trends</h2>
              <Textarea className="text-sm" value={\`CFG: "We are exploring monetizing our owned branches"
WAL: "Open to non-core asset sales, including property"
PB: "Too early to discuss sale-leaseback, but evaluating capital flexibility"
FFIN: "No plans for SLB given owned-to-branch ratio under 30%"\`} readOnly rows={6} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
